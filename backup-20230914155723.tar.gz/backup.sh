#!/bin/bash

# Set the source and destination directories
source_dir="/home/oscar_rincon/code/oandresrincon/Hands-on Introduction to Linux/"
backup_dir="/home/oscar_rincon/code/oandresrincon/Hands-on Introduction to Linux/"
mkdir -p "$backup_dir"

# Define the timestamp for the backup filename
timestamp=$(date +%Y%m%d%H%M%S)

# Define the backup filename
backup_filename="backup-$timestamp.tar.gz"

# Create a compressed tarball of the encrypted password files
tar -czf "$backup_dir/$backup_filename" -C "$source_dir" .

echo "Backup completed: $backup_filename"

